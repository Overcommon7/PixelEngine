#include "pch.h"
#include "System.h"

int main()
{
    return System::Run();
}