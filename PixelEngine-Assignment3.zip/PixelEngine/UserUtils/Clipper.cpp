#include "pch.h"
#include "Clipper.h"
#include "Utilities.h"

Vertex Clipper::ComputeIntersection(const Vertex& prev, const Vertex& current, const Edge& edge)
{
    double a = current.pos.y - prev.pos.y;
    double b = prev.pos.x - current.pos.x;
    double c = a * (prev.pos.x) + b * (prev.pos.y);

    double a1 = edge.end.y - edge.start.y;
    double b1 = edge.start.x - edge.end.x;
    double c1 = a1 * edge.start.x + b1 * (edge.start.y);
    double det = a * b1 - a1 * b;
    if (det == 0)  
        return Vertex({ INFINITY, INFINITY });
    float y = ((a * c1) - (a1 * c)) / det;
    float x = ((b1 * c) - (b * c1)) / det;
    return Vertex({x , y}, Utils::LerpColor(prev.color, current.color, (y - prev.pos.y) / (current.pos.y - prev.pos.y)));
}

void Clipper::Update()
{
    
}

void Clipper::Draw()
{
    if (!displayViewport) return;
    if (!mClipping) return;

    Rectangle vp = viewport;
    vp.x *= Draw::GetPixelSize();
    vp.y *= Draw::GetPixelSize();
    vp.width *= Draw::GetPixelSize();
    vp.height *= Draw::GetPixelSize();
    Utils::DrawRectangleLines(vp, color);
}

bool Clipper::ClipPoint(const Vertex& v)
{
    if (!mClipping) return true;
    if (v.pos.x < viewport.x || v.pos.x > viewport.x + viewport.width) return false;
    if (v.pos.y < viewport.y || v.pos.y > viewport.y + viewport.height) return false;
    return true;
}

bool Clipper::ClipLine(Vertex& v1, Vertex& v2)
{
    if (!mClipping) return true;
    double slope = 0;
    bool v1start = false;
    if (abs(v1.pos.y - v2.pos.y) < abs(v1.pos.x - v2.pos.x)) v1start = v1.pos.x < v2.pos.x;
    else v1start = v1.pos.y < v2.pos.y;
    if (v1start) slope = ((v1.pos.y - v2.pos.y) / (v1.pos.x - v2.pos.x));
    else slope = ((v2.pos.y - v1.pos.y) / (v2.pos.x - v1.pos.x));
    double b = v1.pos.y - (slope * v1.pos.x);

    double leftY, rightY, topX, bottomX;

    leftY = slope * viewport.x + b;
    rightY = slope * (viewport.x + viewport.width) + b;
    topX = (viewport.y - b) / slope;
    bottomX = ((viewport.y + viewport.height) - b) / slope;

    if (slope == NAN)
    {
        bottomX = v1.pos.x;
        topX = v1.pos.x;
    }
       
    vector<Vector2> positions;
    if (!(leftY > viewport.y + viewport.height || leftY < viewport.y))
        positions.push_back({ viewport.x, (float)leftY });
    if (!(rightY > viewport.y + viewport.height || rightY < viewport.y))
        positions.push_back({ viewport.x + viewport.width - 1, (float)rightY });

    if (slope != NAN)
    {
        if (!(bottomX > viewport.x + viewport.width || bottomX < viewport.x))
            positions.push_back({ (float)bottomX, viewport.y + viewport.height - 1 });
        if (!(topX > viewport.x + viewport.width || topX < viewport.x))
            positions.push_back({ (float)topX, viewport.y });
    }
   

    if (!ClipPoint(v1) && !positions.empty())
    {
        v1.pos.x = positions.front().x;
        v1.pos.y = positions.front().y;
    }
    if (!ClipPoint(v2) && positions.size() >= 2)
    {
        v2.pos.x = positions.back().x;
        v2.pos.y = positions.back().y;
    }

    if (!ClipPoint(v1) && !ClipPoint(v2)) return false;
    return true;
}

bool Clipper::ClipTriangle(std::vector<Vertex>& vertices)
{
    if (!mClipping) return true;
    const vector<Edge> edges =
    {
        {{viewport.x, viewport.y}, {viewport.x + viewport.width, viewport.y}},
        {{viewport.x, viewport.y}, {viewport.x + viewport.y + viewport.height}},
        {{viewport.x + viewport.width, viewport.y}, {viewport.x + viewport.width, viewport.y + viewport.height}},
        {{viewport.x, viewport.y + viewport.height}, {viewport.x + viewport.width, viewport.y + viewport.height}}
    };

    vector<Vertex> outputList = vertices;

    for (const auto& clipEdge : edges)
    {       
        vector<Vertex> inputList = outputList;
        outputList.clear();

        for (short i = 0; i < inputList.size(); i++)
        {
            Vertex current = inputList[i];
            Vertex prev = inputList[(i + 1) % inputList.size()];

            if (ClipPoint(current))
            {
                if (!ClipPoint(prev))
                {
                    Vertex v = ComputeIntersection(prev, current, clipEdge);
                    if (v.pos.x != INFINITY)
                        outputList.push_back(v);
                }
                outputList.push_back(current);
            }
            else if (ClipPoint(prev))
            {
                Vertex v = ComputeIntersection(prev, current, clipEdge);
                if (v.pos.x != INFINITY)
                    outputList.push_back(v);
            }
        }
    }
    vertices = outputList;
    return vertices.size() >= 3;
}