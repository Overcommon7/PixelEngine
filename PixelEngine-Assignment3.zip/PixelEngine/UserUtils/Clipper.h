#pragma once
#include "Vertex.h"
#include "Defines.h"
#include "Draw.h"



struct Edge
{
    Vector2 start;
    Vector2 end;
};

class Clipper
{
    Clipper() = delete;
    Clipper(const Clipper& c) = delete;
    Clipper& operator=(const Clipper& c) = delete;

    static inline bool mClipping = true;
    static inline bool displayViewport = false;
    static inline Rectangle viewport = { 0, 0, 0, 0 };
    static inline Color color = RED;

    static Vertex ComputeIntersection(const Vertex& prev, const Vertex& current, const Edge& edge);
public:

    static void Update();
    static void Draw();

    static bool ClipPoint(const Vertex& v);
    static bool ClipLine(Vertex& v1, Vertex& v2);
    static bool ClipTriangle(vector<Vertex>& vertices);

    static bool IsClipping() { return mClipping; }
    static void SetClipping(bool clip) { mClipping = clip; }
    static void SetViewport(const Rectangle& vp) { viewport = vp; }
    static void ShowViewport(bool show) { displayViewport = show; }
    static void SetViewportColor(const Color& c) { color = c; }
};

