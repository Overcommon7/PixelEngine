#pragma once
class SymbolDefines
{
};

